for(a=1; a<=100;a +=10){
	for (b=a;b<=a+10;b++){
	document.write(b+" ")
	}
	document.write("<br>")
	}


	var spec = prompt("welcome to Saylani", "Here to Help");
	var spec = prompt("i m TARIS ");

	
	var hello = "Hello World";
function sayHello(){
  return hello;
}
console.log(hello);
