var a = "TARIS";
var b = "MASIH";
var c = 31;
var d = "Hello " + a + " " + b + ", You are " + c + " years old"
window.alert(d);

var c=prompt("Enter any character.");





