alert ("Wel come Taris Online")

prompt ("Error Please enter a vlaid password");

alert("Welcome JS Land...\nHappy Coding ;-)")

alert (" ")

var a = "Hello... i can run JS"
var b = "through my web browser console"
var c = a+b;
console.log(c);






