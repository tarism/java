var a = 2;
var b = a++ + ++a - --a + a--;
window.alert(a);
window.alert(b);