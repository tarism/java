var a = prompt("Please Enter your First Name");
var b = prompt("Please Enter your Last Name");
var c = prompt("Please Enter your Age");
var d = "Hello " + a + " " + b + ", You are " + c + " years old"
window.alert(d);