var val1=prompt('Enter your first value')
var val2=prompt('Enter your second value')
var val3=prompt('Enter your operator')

console.log(val1+sign+val2)
if (sign === '+'){
  alert(val1+val2)
}else if(sign === '-'){
  alert(val1-val2)
}else if(sign === '*'){
  alert(val1*val2)
}else if(sign === '/'){
  alert(val1/val2)
}









var city = prompt("Enter your City Name");

if (city === "karachi"){
    alert("Welcome to cityof lights");
}else {
    alert("You are not eligible");
}




var gender = prompt("enter your gender");

if (gender === "male"){
    alert(" Good Morning Sir")
}else{
    alert("Good Morning Mama")
}




var time = 5;

function functionary() {
  var red = document.getElementById('redL')
  var yellow = document.getElementById('yellowL')
  var green = document.getElementById('greenL')
  var Colours = ["#FF0000", "#FFB300", "#05FF0D", "#7A0000", "#7A5C00", "#008000"];
  if (time == 5) {
    red.style.background = Colours[0]; // May need spacebar between index number
    yellow.style.background = Colours[4];
    green.style.background = Colours[5];
    time = 1;
  } else if (time == 2 || time == 4) {
    red.style.background = Colours[3];
    yellow.style.background = Colours[1];
    green.style.background = Colours[5];
  } else if (time == 3) {
    red.style.background = Colours[3];
    yellow.style.background = Colours[4];
    green.style.background = Colours[2];
  }
  time += 1;
};
setInterval(function() {
  functionary();
}, 3000);


var name = new Array(5);
var roll = new Array(5);
var m1 = new Array(5);
var m2 = new Array(5);
var m3 = new Array(5);
var total = new Array(5);
var avg = new Array(5);
var i = 1;

function A() {
    m1[i] = parseInt(document.getElementById('m1').value);
    m2[i] = parseInt(document.getElementById('m2').value);
    m3[i] = parseInt(document.getElementById('m3').value);
    avg[i] = (m1[i] + m2[i] + m3[i]) / 3;
    total[i] = (m1[i] + m2[i] + m3[i]);
    var mark = "Avg=" + avg[i] + "<br> Total=" + total[i];
    document.getElementById("1").innerHTML = mark;
    i++;
}

function input() {
    document.write(" <form name='stud'> ");
    document.write(" Enter Name  :<input type='text' name='name'><br>");
    document.write(" Enter RollNo:<input type='number' name='no'><br>");
    document.write(" Enter mark 1:<input type='number' name='m1' id='m1'><br>");
    document.write(" Enter mark 2:<input type='number' name='m2' id='m2'><br>");
    document.write(" Enter mark 3:<input type='number' name='m3' id='m3'><br>");
    document.write("<input type='button' value='calculate' onclick='A();'>");
    document.write(" <br>");
    document.write("<input type='button' value='Enter For Next Student' onclick='input()'>");
    document.write(" <br><p id='1'></p>   ");
}