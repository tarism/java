var x = 5;
var y = x++ + ++x + x + --x + x-- -x
document.write(y);



var a = prompt ("Enter your age", "your age is")
var b = a + 10;
alert("The output is", + " " + b)



var x = "Enter value";
var y = "Your value is:"
var a = +prompt(x,y);
var b = a + 10;
console.log("The output is" + " " + b)




var a = Number(prompt("Enter Marks Obtained in Subject1"));
var b = Number(prompt("Enter Marks Obtained in Subject2"));
var c = Number(prompt("Enter Marks Obtained in Subject3"));
var d = Number(prompt("Enter Marks Obtained in Subject4"));
var e = Number(prompt("Enter Marks Obtained in Subject5"));
var obtainedMarks = a + b + c + d +e; 
var totalMarks = 500;
var formula = obtainedMarks * 100 / totalMarks;
alert (formula + "%");
window.alert(formula);



var percent = +prompt("Enter your percent")
if(percent >= 80 && percent <= 100){
    alert("A+")
}
else if(percent >= 70 && percent <= 80){
    alert("A")
}
else if(percent >= 60 && percent <= 70){
    alert("B")
}
else if(percent >= 50 && percent <= 60){
    alert("C")
}
else if(percent >= 40 && percent <= 50){
    alert("D")
}
else if(percent >= 33 && percent <= 40){
    alert("E")
}
else if(percent >= 0 && percent <= 33){
    alert("F")
}
else{
    alert("You didnot write correct percentage")
}





var Subject1 = prompt("enter subject 1");
var Subject2 = prompt("enter subject 2");
var Subject3 = prompt("enter subject 3");

var total = 100;

var sub1Obtained = prompt("Enter " + subject1 + "Marks")
var sub2Obtained = prompt("Enter " + subject2 + "Marks")
var sub3Obtained = prompt("Enter " + subject3 + "Marks")

var obtainedMarks = a + b + c + d +e; 
var totalMarks = 500;
var formula = obtainedMarks * 100 / totalMarks;
alert (formula + "%");
window.alert(formula);